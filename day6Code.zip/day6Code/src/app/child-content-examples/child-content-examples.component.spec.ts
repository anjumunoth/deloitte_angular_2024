import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildContentExamplesComponent } from './child-content-examples.component';

describe('ChildContentExamplesComponent', () => {
  let component: ChildContentExamplesComponent;
  let fixture: ComponentFixture<ChildContentExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ChildContentExamplesComponent]
    });
    fixture = TestBed.createComponent(ChildContentExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
