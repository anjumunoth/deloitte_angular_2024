import { Component } from '@angular/core';
import { CartProduct } from '../cart-product';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  showCart: boolean;
  btnTitle: string;
  cartArr: CartProduct[];
  constructor() {
    this.cartArr=new Array<CartProduct>();
    this.showCart = false;
    this.btnTitle = "Cart"
  }
  showCartEventHandler() {
    if (this.btnTitle == "Cart") {
      this.showCart = true;
      this.btnTitle = "Products"
    }
    else {
      this.showCart = false;
      this.btnTitle = "Cart"
    }
  }
  sendcartArrFromPlToHomeEventHandler(cartObj:CartProduct)
  {
    console.log("In home component : cartObj",cartObj);
    this.cartArr.push(cartObj);
  }
}
