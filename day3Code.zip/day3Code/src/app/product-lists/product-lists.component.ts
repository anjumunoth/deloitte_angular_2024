import { Component } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-product-lists',
  templateUrl: './product-lists.component.html',
  styleUrls: ['./product-lists.component.css']
})
export class ProductListsComponent {
  productsArr:Products[];
  showAddToCartComponent:boolean;
  constructor()
  {
    this.showAddToCartComponent=false;
    this.productsArr=[
      new Products(101,"Apple 15 Pro Max",125000,12,"White Iplone Pro max 256gb","./assets/iphone15.jpeg"),
      new Products(102,"Oppo Fold",85000,5,"Oppo Fold 7.2 White Colour","./assets/oppofold.jpg"),
      new Products(103,"Pixel 8 Pro",55000,5,"Pixel 8 Pro","./assets/pixel8pro.jpg"),
      new Products(104,"Samsung Fold",150000,1,"Samsung Fold 7.2 White Colour","./assets/samsungfold4.jpg"),
      new Products(105,"Samsung Ultra 24Pr",115000,7,"Samsung Ultra24 White Colour","./assets/samsungs24.jpg"),
    ];
  }
  addToCartEventHandler(selectedProduct:Products)
  {
    alert("Button clicked" + selectedProduct.productName);
    this.showAddToCartComponent=true;
  }
}
