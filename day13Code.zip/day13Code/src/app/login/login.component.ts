import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormControlDirective, FormGroup, Validators } from '@angular/forms';
import { UserManagementService } from '../user-management.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm:FormGroup;
  constructor(private formBuilder : FormBuilder,private userService:UserManagementService, private router:Router)
  {
this.loginForm=this.formBuilder.group({
  username:new FormControl("",Validators.required),
  password :new FormControl("",Validators.required)
})
  }
  loginEventHandler()
  {
    var username=this.loginForm.get('username')?.value;
    // send the data to user management service
    this.userService.confirmLoggedIn(username);
    this.router.navigate(["/products"]);
  }
}
