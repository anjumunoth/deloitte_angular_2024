import { Component } from '@angular/core';

@Component({
  selector: 'app-directive-examples',
  templateUrl: './directive-examples.component.html',
  styleUrls: ['./directive-examples.component.css']
})
export class DirectiveExamplesComponent {
 
myCustomBorder:string;
myCustomBorder2:string;
myBgStyle:string;
joinText:string;
componentText:string;
constructor()
{
  this.componentText="Directive added to a compoenet";
  this.myCustomBorder="3px solid green";
  this.myCustomBorder2="7px double red";
  this.myBgStyle="cyan";
  this.joinText="Join Deloitte today !!!!!"
}
}
