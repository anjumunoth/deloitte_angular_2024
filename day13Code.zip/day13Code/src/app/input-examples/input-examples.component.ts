import { Component,Input,booleanAttribute,numberAttribute } from '@angular/core';

@Component({
  selector: 'app-input-examples',
  templateUrl: './input-examples.component.html',
  styleUrls: ['./input-examples.component.css']
})
export class InputExamplesComponent {
@Input() data1:string;
@Input() data2:string;
@Input() year:number;
@Input() data3:number;
@Input({
  required:true,
}) data4:string[];

private selectedUserName:string;
@Input() 
get userName() {
  return this.selectedUserName;
}

set userName(value:string)
{
  this.selectedUserName=value.toUpperCase();
  
}

/* private reviewList:string[];
@Input() 
get reviews()
{
  return this.reviewList;
}
set reviews(value:string[])
{
  this.reviewList=[...(new Set(value))];
}
 */
// Alternate to getters and setters
@Input({
  transform: (value:string[])=>{
    // perform any kind of transformation
    // return the transformed data
    return [...(new Set(value))]
  }
}) reviews:string[];



// @Input('trainingName') courseName:string; 

@Input({alias:'trainingName',required:true}) courseName:string; 

@Input({
  transform:booleanAttribute
}) cancelDisabled:boolean;
@Input({
  transform :numberAttribute,
}) month:number;

constructor()
{
  this.month=5;
  this.cancelDisabled=false;

  this.data1="Spring People";
  this.data2="";
  this.year=(new Date()).getFullYear();
  this.data3=5000;
  this.data4=["apple"];
  
  this.selectedUserName="Jack";
  console.log("Selected UserName"+this.selectedUserName);
  //this.reviewList=[];
  this.reviews=[];
  this.courseName="";
}
}
