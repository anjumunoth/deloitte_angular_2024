import { AfterContentChecked, AfterViewChecked, Component } from '@angular/core';
import { UserManagementService } from '../user-management.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements AfterViewChecked,AfterContentChecked {
  loggedInStatus:boolean;
  username:string;
  constructor(private userManagement:UserManagementService)
  {
    this.loggedInStatus=userManagement.getLoggedInStatus();
    this.username=userManagement.getUsername();
  }
  ngAfterViewChecked(): void {
   console.log("After view checked of menu component");
   
  }
  ngAfterContentChecked(): void {
    console.log("After content checked of menu component");
    this.loggedInStatus=this.userManagement.getLoggedInStatus();
    this.username=this.userManagement.getUsername();
  }

  logoutUserEventHandler()
  {
    this.userManagement.logoutUser();
  }
  

}

