import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-upi',
  templateUrl: './payment-by-upi.component.html',
  styleUrls: ['./payment-by-upi.component.css']
})
export class PaymentByUpiComponent {

}
