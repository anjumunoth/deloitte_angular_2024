export class Employee {
    empId:number;
    empName:string;
    salary:number;
    doj:Date;
    constructor(empId:number,empName:string,salary:number,doj:Date)
    {
        this.empId= empId;
        this.empName=empName;
        this.salary=salary;
        this.doj=doj;
        
    }
}
