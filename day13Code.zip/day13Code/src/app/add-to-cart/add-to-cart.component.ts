import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import {Products} from  "../products"
import { CartProduct } from '../cart-product';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnDestroy,OnChanges
{
  quantitySelected:number;
@Input() companyName:string;
@Input({required:true,alias:"selProduct"}) product:Products|null;
@Output() onConfirmSubmission:EventEmitter<CartProduct>;
@Output() onCancelSubmission:EventEmitter<void>;

  constructor()
  {

    this.companyName="";
    this.product=null;
    console.log("Inside the constructor product: ",this.product);//null
    this.quantitySelected=1;
    this.onConfirmSubmission=new EventEmitter<CartProduct>();
    this.onCancelSubmission=new EventEmitter<void>();
    console.log("Constructor of AddToCartComponenet called");
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("ngOnChanges called in AddToCartComponent");
    console.log("SimpleChanges object : ",changes);
    console.log("Selected product in ngOnChanges",this.product);// product details from the parent for the first time also
    // will be called whenever the bound property/properties/ any of bound property changes changes
    if(changes['product'] && !changes['product'].firstChange && changes['product'].currentValue.productId != changes['product']?.previousValue.productId)
    {
      this.quantitySelected=1;
    }
    
  }
  ngOnDestroy(): void {
    alert("Are u sure with your decision??");
  }
  changeQuantitySelected(choice:string)
  {
    if(choice=="inc")
    {
      this.quantitySelected++;
    }
    else
    {
      this.quantitySelected--;
    }

  }
  confirmEventHandler()
  {
    // add the selected product to the cart
    //var newCartItem:CartProduct=new CartProduct(this.product?.productId,this.product?.productName,this.product?.price,this.product?.quantity,this.product?.description,this.product?.imgUrl,this.quantitySelected);
    var newCartItem:CartProduct|any={...this.product,quantitySelected:this.quantitySelected};
    //pass data to the parent -- product added to the cart
    // trigger or emit the event
    this.onConfirmSubmission.emit(newCartItem);
    
    // unmount the AddToCartComponent
  }
  cancelEventHandler()
  {
    this.onCancelSubmission.emit();
  }
}
