import { Component } from '@angular/core';

@Component({
  selector: 'app-child-content-examples',
  templateUrl: './child-content-examples.component.html',
  styleUrls: ['./child-content-examples.component.css']
})
export class ChildContentExamplesComponent {

}
