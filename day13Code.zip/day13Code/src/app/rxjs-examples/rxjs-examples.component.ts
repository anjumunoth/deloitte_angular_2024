import { Component } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-rxjs-examples',
  templateUrl: './rxjs-examples.component.html',
  styleUrls: ['./rxjs-examples.component.css']
})
export class RxjsExamplesComponent {
  constructor()
  {
    // declare the observable
   let observableObj= new Observable((subscriber)=>{
      subscriber.next(1);
      subscriber.next(2);
      subscriber.next(3);
      subscriber.next(4);
      setTimeout(()=>{
        subscriber.next(5);
        subscriber.complete();
      },10000);
      return ()=>{
        // unsubscribe from the observable
        console.log("Time to wrap up from the observable");
      }
     
    })
    console.log("Before subscription");
    // subscribe to the observable; observable will get executed;
    let subscription1=observableObj.subscribe({
    next(num){
      console.log("Value in next",num);
    },
    complete()
    {
      console.log("Stream over");
    },
    error(err)
    {
      console.log("Error in observable",err)
    }
    })

    let subscription2=observableObj.subscribe({
      next(num){

        console.log("Value in next in second observer",(num));
      },
      complete()
      {
        console.log("Stream over in second observer");
      },
      error(err)
      {
        console.log("Error in observable",err)
      }
      })
      
    console.log("After subscription");
    //unsubscribe the observable
    subscription1.unsubscribe();
  }


}



