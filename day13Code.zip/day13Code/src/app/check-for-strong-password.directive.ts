import { Directive } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';
import { strongPassword } from './Validators/strongPassword';
@Directive({
  selector: '[checkForStrongPassword]',
  providers: [{
    provide: NG_VALIDATORS,
    useExisting: CheckForStrongPasswordDirective,
    multi: true
  }]

})
export class CheckForStrongPasswordDirective implements Validator {

  constructor() { }
  /* validate(control: AbstractControl<any, any>): ValidationErrors | null {
    //console.log("Control",control);
    var strength:number=-1;
    if(control.value)
    {
      if(control.errors)
      {
    
        return null;
      }
      else
      {
        if(/[a-z]/.test(control.value))
          {strength++}
        if(/[A-Z]/.test(control.value))
          {strength++}
        if(/\d/.test(control.value))
          {strength++}
        if(/[^a-zA-Z0-9]/.test(control.value))
          {strength++}
        if(strength == 3)
        {
          if(control.value.length >=8 && control.value.length <=12)
            return null;
          else
            return { checkForStrongPassword:{"LengthNotCorrect":true}}
        }
        else
        {
          return { checkForStrongPassword:{"PatternNotMatching":true}}
        }
      }
    }
    return null;
  } */
  validate(control: AbstractControl<any, any>): ValidationErrors | null {
    //console.log("Control",control);
    return strongPassword()(control);
  }

}
