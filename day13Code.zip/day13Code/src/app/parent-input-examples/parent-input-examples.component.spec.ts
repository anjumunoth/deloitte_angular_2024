import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParentInputExamplesComponent } from './parent-input-examples.component';

describe('ParentInputExamplesComponent', () => {
  let component: ParentInputExamplesComponent;
  let fixture: ComponentFixture<ParentInputExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ParentInputExamplesComponent]
    });
    fixture = TestBed.createComponent(ParentInputExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
