import { AbstractControl } from "@angular/forms";

export function strongPassword()
{
    return function(control:AbstractControl){
        var strength:number=-1;
    if(control.value)
    {
      if(control.errors)
      {
    
        return null;
      }
      else
      {
        if(control.value.length <=8 || control.value.length >=12)
            return { checkForStrongPassword:{"LengthNotCorrect":true}}

        if(/[a-z]/.test(control.value))
          {strength++}
        if(/[A-Z]/.test(control.value))
          {strength++}
        if(/\d/.test(control.value))
          {strength++}
        if(/[^a-zA-Z0-9]/.test(control.value))
          {strength++}
        if(strength == 3)
        {
          return null;
        }
        else
        {
          return { checkForStrongPassword:{"PatternNotMatching":true}}
        }
      }
    }
    return null;
    }

    
}