import { Component } from '@angular/core';

@Component({
  selector: 'app-parent-input-examples',
  templateUrl: './parent-input-examples.component.html',
  styleUrls: ['./parent-input-examples.component.css']
})
export class ParentInputExamplesComponent {
companyName:string;
myFruits:string[];
userName:string;
reviews:string[];
trainingName:string;
isCancelDisabled:boolean;
constructor()
{
  this.companyName="Sping People";
  this.myFruits=["apple","strawberry","banana"];
  this.userName="sara";
  this.reviews=["good","excellent","good","Very good","ok"]
  this.trainingName="Angular";
  this.isCancelDisabled=true;
}
}
