import { Directive,HostBinding,HostListener,Input, OnChanges } from '@angular/core';

@Directive({
  selector: 'img[appImageChange]'
})
export class ImageChangeDirective implements OnChanges {
@Input('appImageChange') config:any;

@HostBinding("src") private imagePath:string;

  constructor() { 
    this.imagePath="";
  }
  ngOnChanges()
  {
    console.log(this.config);
    if(this.config.initial)
    {
      this.imagePath=this.config.initial;
    }
    else
    {
      this.imagePath="./assets/noImage.png"
    }
  }
  @HostListener("mouseover") onMouseOver()
  {
    this.imagePath=this.config.hover;
  }
  @HostListener("mouseout") onMouseOut()
  {
    this.imagePath=this.config.initial;
  }

 }
