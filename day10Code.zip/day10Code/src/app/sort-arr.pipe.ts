import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortArr'
})
export class SortArrPipe implements PipeTransform {

  transform(value:any, selectedFieldName:string,selectedOrder:string)  {
    
    console.log("Selected Field for sorting"+ selectedFieldName);
    console.log("Selected order for sorting"+ selectedOrder);
      if(selectedOrder =="" || !selectedOrder)
    {
      selectedOrder="asc";
    }
    selectedOrder=selectedOrder.toLowerCase();
    if(selectedFieldName ==""  )
    {
      return value;
    }
    if(selectedFieldName && selectedFieldName!="")
    {
      if(selectedOrder=="asc")
      {
        for(let i=0;i<value.length;i++)
        {
          for(let j=i+1;j<value.length;j++)
          {

            if(value[i][selectedFieldName] > value[j][selectedFieldName])
            {
              let temp=value[i];
              value[i]=value[j];
              value[j]=temp;
            }
          }
        }
      }
      else
      {
        //selectedOrder=="desc"
        console.log("value",value);
        
        for(let i=0;i<value.length;i++)
        {
          for(let j=i+1;j<value.length;j++)
          {
            if(value[i][selectedFieldName] < value[j][selectedFieldName])
            {
              let temp=value[i];
              value[i]=value[j];
              value[j]=temp;;
            }
          }
        }
      }
    }
    return value;;
  }

}
