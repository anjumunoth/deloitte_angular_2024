import { CheckLengthDirective } from './check-length.directive';

describe('CheckLengthDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckLengthDirective();
    expect(directive).toBeTruthy();
  });
});
