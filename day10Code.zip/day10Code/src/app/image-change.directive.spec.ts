import { ImageChangeDirective } from './image-change.directive';

describe('ImageChangeDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageChangeDirective();
    expect(directive).toBeTruthy();
  });
});
