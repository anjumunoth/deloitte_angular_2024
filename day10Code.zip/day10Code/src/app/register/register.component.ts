import { Component, ViewChild } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  @ViewChild("registerForm") registerForm:any;
  constructor()
  {

  }
  submitEventHandler()
  {
    console.log("Form details ",this.registerForm);
  }
}
