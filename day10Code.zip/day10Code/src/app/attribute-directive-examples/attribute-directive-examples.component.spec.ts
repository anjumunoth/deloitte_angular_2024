import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttributeDirectiveExamplesComponent } from './attribute-directive-examples.component';

describe('AttributeDirectiveExamplesComponent', () => {
  let component: AttributeDirectiveExamplesComponent;
  let fixture: ComponentFixture<AttributeDirectiveExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AttributeDirectiveExamplesComponent]
    });
    fixture = TestBed.createComponent(AttributeDirectiveExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
