import { PopUp2Directive } from './pop-up2.directive';

describe('PopUp2Directive', () => {
  it('should create an instance', () => {
    const directive = new PopUp2Directive();
    expect(directive).toBeTruthy();
  });
});
