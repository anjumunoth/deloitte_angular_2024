import { Directive, HostListener,ElementRef,Input } from '@angular/core';

@Directive({
  selector: '[checkLength]'
})
export class CheckLengthDirective {
@Input("checkLength") textBoxlength:number;
  constructor(private el:ElementRef) { 
    this.textBoxlength=10;
  }
  @HostListener("keypress") OnKeyPress()
  {
    this.el.nativeElement.style.backgroundColor="yellow";
    if(this.el.nativeElement.value.length >= this.textBoxlength)
    {
      return false;
    }
    else
    {
      return true;
    }
  }
  @HostListener("blur") OnBlur()
  {
    this.el.nativeElement.style.backgroundColor="";
  }

}
