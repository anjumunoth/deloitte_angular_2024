import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { customMinValue } from '../Validators/minValue';
import { mustMatch } from '../Validators/mustMatch';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {
  addProductForm: FormGroup
  productName: FormControl;
  description: FormControl;
  price: FormControl;
  quantity: FormControl;
  constructor() {
    this.productName = new FormControl("", Validators.required);
    this.description = new FormControl("", [Validators.required, Validators.minLength(20)]);
    this.price = new FormControl("", [Validators.required,customMinValue(10)]);
    this.quantity = new FormControl("", [Validators.required,customMinValue(1)]);
    this.addProductForm = new FormGroup({});
    this.addProductForm.addControl("description", this.description);
    this.addProductForm.addControl("productName", this.productName);
    this.addProductForm.addControl("price", this.price);
    this.addProductForm.addControl("quantity", this.quantity);

  }
  onSubmitEventHandler() {
    console.log("Entered values", this.addProductForm.value);
  }

}
