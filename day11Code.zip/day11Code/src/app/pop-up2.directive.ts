import { Directive, ElementRef,OnInit,Input } from '@angular/core';

@Directive({
  selector: '[appPopUp2]'
})
export class PopUp2Directive implements OnInit {
@Input() popUpText:string;
  constructor(private el:ElementRef) { 
    this.popUpText=""
  
  }
  ngOnInit()
  {
    console.log("In popup 2 : popUpText",this.popUpText);
  }

}
