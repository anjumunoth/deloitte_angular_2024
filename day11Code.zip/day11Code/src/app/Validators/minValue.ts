import { AbstractControl } from "@angular/forms";

export function customMinValue(decidedMinValue:number)
{
    return (control:AbstractControl)=>{
        if(!control)
        {
            return null;
        }
        if(control.errors)
        {
            return null;
          
        }
        if(control.value > decidedMinValue)
        {
            return null;
        }
        else
        {
            control.setErrors({customMinValue:true});
            return ({customMinValue:true});
        }
        return null;
    }
}