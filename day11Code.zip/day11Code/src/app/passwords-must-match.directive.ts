import { Directive,Input } from '@angular/core';
import { AbstractControl, FormGroup, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';
import { mustMatch } from './Validators/mustMatch';

@Directive({
  selector: '[passwordsMustMatch]',
  providers:[{
    provide:NG_VALIDATORS,
    useExisting:PasswordsMustMatchDirective,
    multi:true
  }]
})
export class PasswordsMustMatchDirective implements Validator {
  @Input() passwordsMustMatch:string[];

  constructor() { 
    this.passwordsMustMatch=[];
  }
  validate(formGroup:FormGroup): ValidationErrors | null {
    return mustMatch(this.passwordsMustMatch[0],this.passwordsMustMatch[1])(formGroup);
  }
  

}
