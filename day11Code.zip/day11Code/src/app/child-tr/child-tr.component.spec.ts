import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildTrComponent } from './child-tr.component';

describe('ChildTrComponent', () => {
  let component: ChildTrComponent;
  let fixture: ComponentFixture<ChildTrComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ChildTrComponent]
    });
    fixture = TestBed.createComponent(ChildTrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
