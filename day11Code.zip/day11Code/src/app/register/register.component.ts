import { Component, ViewChild } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  @ViewChild("registerForm") registerForm:any;
  constructor()
  {

  }
  submitEventHandler()
  {
    console.log("Form details ",this.registerForm);
    console.log("Form details ",this.registerForm.form.value);
    // send these details to server
    // based on server's response
    // register the user -- successful -- route the user to login page
    // register the user -- failure -- display the error message
  }
}
