import { Component } from '@angular/core';

@Component({
  selector: 'app-image-hover',
  templateUrl: './image-hover.component.html',
  styleUrls: ['./image-hover.component.css']
})
export class ImageHoverComponent {
  imageObject:any;
  constructor()
  {
    this.imageObject={'initial':'./assets/image1.jpg',hover:'./assets/image22.jpg'};
  }
  showWaterfallsImageEventHandler()
  {
    this.imageObject={'initial':'./assets/waterfall1.jpg',hover:'./assets/waterfall2.jpg'};
  }
}
