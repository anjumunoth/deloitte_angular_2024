import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string = 'FirstProject';
  companyName: string = "Deloitte";
  numberOfYearsSinceStarted: number = 10;
  dateOfStart: Date = new Date(2014, 11, 14);
  singleOwner: boolean = false;
  citiesPresent: string[] = ["Chennai", "Mumbai", "Delhi"];
  headOfficeAddress: any = { houseNumber: 10, area: "Ville Parle", city: "Mumbai" };
  colours:any[]=[];
  employeeDetails= [{
    "empId": 101,
    "empName": "asha",
    "salary": 1001,
    "deptId": "D1"
  }, {
    "empId": 102,
    "empName": "Gaurav",
    "salary": 2000,
    "deptId": "D1"
  }, {
    "empId": 103,
    "empName": "Karan",
    "salary": 2000,
    "deptId": "D2"
  },
    {
      "empId": 104,
      "empName": "Kishan",
      "salary": 3000,
      "deptId": "D1"
    },
    {
      "empId": 105,
      "empName": "Keshav",
      "salary": 3500,
      "deptId": "D2"
    },
    {
      "empId": 106,
      "empName": "Pran",
      "salary": 4000,
      "deptId": null,
      "hobbies": ["singing", "dancing", "cooking"],
      "isMarried": false
    },
    {
      "empId": 107,
      "empName": "Saurav",
      "salary": 3800
    }
  ];
  todaysDate:Date=new Date();
}
