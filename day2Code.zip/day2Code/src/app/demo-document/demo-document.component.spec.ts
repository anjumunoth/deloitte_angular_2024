import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DemoDocumentComponent } from './demo-document.component';

describe('DemoDocumentComponent', () => {
  let component: DemoDocumentComponent;
  let fixture: ComponentFixture<DemoDocumentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DemoDocumentComponent]
    });
    fixture = TestBed.createComponent(DemoDocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
