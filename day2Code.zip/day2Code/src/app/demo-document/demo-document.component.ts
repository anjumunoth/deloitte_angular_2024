import { Component } from '@angular/core';

@Component({
  selector: 'app-demo-document',
  templateUrl: './demo-document.component.html',
  styleUrls: ['./demo-document.component.css']
})
export class DemoDocumentComponent {

}
