import { Component } from '@angular/core';

@Component({
  selector: 'app-sampledocument',
  templateUrl: './sampledocument.component.html',
  styleUrls: ['./sampledocument.component.css']
})
export class SampledocumentComponent {

}
