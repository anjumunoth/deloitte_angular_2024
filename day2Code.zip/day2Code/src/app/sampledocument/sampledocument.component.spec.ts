import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SampledocumentComponent } from './sampledocument.component';

describe('SampledocumentComponent', () => {
  let component: SampledocumentComponent;
  let fixture: ComponentFixture<SampledocumentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SampledocumentComponent]
    });
    fixture = TestBed.createComponent(SampledocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
