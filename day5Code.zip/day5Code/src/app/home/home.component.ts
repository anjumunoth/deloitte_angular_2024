import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  showCart: boolean;
  btnTitle: string;
  constructor() {
    this.showCart = false;
    this.btnTitle = "Cart"
  }
  showCartEventHandler() {
    if (this.btnTitle == "Cart") {
      this.showCart = true;
      this.btnTitle = "Products"
    }
    else {
      this.showCart = false;
      this.btnTitle = "Cart"
    }
  }
}
