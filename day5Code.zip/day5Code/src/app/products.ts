export class Products {
    productId:number;
    productName:string;
    price:number;
    description :string;
    imgUrl:string;
    quantity:number;
    constructor(pId:number,pName:string,price:number,quantity:number,desc: string, imgUrl:string)
    {
        this.productId=pId;
        this.productName=pName;
        this.description=desc;
        this.price=price;
        this.imgUrl=imgUrl;
        this.quantity=quantity;

    }

}
