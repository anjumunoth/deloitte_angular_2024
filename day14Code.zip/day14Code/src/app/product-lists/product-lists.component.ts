import { Component, EventEmitter, Output } from '@angular/core';
import { Products } from '../products';
import { CartProduct } from '../cart-product';
import { WorkWithProductsService } from '../work-with-products.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-lists',
  templateUrl: './product-lists.component.html',
  styleUrls: ['./product-lists.component.css']
})
export class ProductListsComponent {
  @Output() sendcartArrFromPlToHome:EventEmitter<CartProduct>|any;
  productsArr:Products[];
  showAddToCartComponent:boolean;
  selectedProduct:Products|null;
  companyName:string;
  constructor(private workWithProduct:WorkWithProductsService, private router:Router)
  {
    this.companyName="SpringPeople";
    this.selectedProduct=null;
    this.showAddToCartComponent=false;
    this.productsArr=workWithProduct.getProductsArr();//reference
    this.sendcartArrFromPlToHome=new EventEmitter<CartProduct>();
  }
  detailsEventHandler(selectedProduct:Products)
  {
    // navigate to /product-details
    //navigate to a static path -- string param
    // navigate to a dynamic path -- array
    // second optional param -- navigationExtras
    // -- relativeTo -- relative path
    // data as part of url -- second param
    this.router.navigate(["/product-details",selectedProduct.productId]);
  }
  addToCartEventHandler(selectedProduct:Products)
  {
    alert("Button clicked" + selectedProduct.productName);
    this.showAddToCartComponent=true;
    this.selectedProduct=selectedProduct;
  }
  onConfirmSubmissionEventHandler(cartObj:CartProduct)
  {
    alert("Data transferred : "+ JSON.stringify(cartObj));
    this.showAddToCartComponent=false;
    var pos:number=this.productsArr.findIndex(item => item.productId == cartObj.productId);
    if(pos >=0)
    {
      this.productsArr[pos].quantity-=cartObj.quantitySelected;
    }
    this.sendcartArrFromPlToHome.emit(cartObj);
  }
  onCancelSubmissionEventHandler()
  {
    this.showAddToCartComponent=false;
  }
  changeNameEventHandler()
  {
    this.companyName="Deloitte";
  }
}

