import { CanDeactivateFn } from '@angular/router';
import { RegisterComponent } from './register/register.component';

export const askForUserConfirmationBeforeLeavingGuard: CanDeactivateFn<unknown> = (component, currentRoute, currentState, nextState) => {
  console.log("Component in CanDeactivate Guard",component );// details of component on which the guard has been applied
  console.log("currentRoute in CanDeactivate Guard",currentRoute );// ActivatedSnapshotRoute of the current component on which the guard has been applied
  console.log("currentState in CanDeactivate Guard",currentState );// current url the user is in 
  console.log("nextState in CanDeactivate Guard",nextState);;// target url of navigation
  if(component instanceof RegisterComponent)
  {
    if(component.registerForm.touched)
    {
      alert("U have unsaved changess")
    }
    
  } 
  var result=confirm("Are u sure u want to leave the page");
  return result;
};
