import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TalkWithServerService {
  usersArr:any[];
  constructor(private httpService: HttpClient) { 
    this.usersArr=[];
  }
  getAllUsersFromJsonPlaceholder()
  {
    
var serverUrl="https://jsonplaceholder.typicode.com/users";
    return this.httpService.get(serverUrl).pipe(
      catchError(this.handleError)
    )
  }
  getAllUsersFromReqRes()
  {
    var serverUrl="https://reqres.in/api/users?page=2";
    

    return this.httpService.get(serverUrl).pipe(
      catchError(this.handleError)
    )
  }
  handleError(error:HttpErrorResponse)
  {
    // network side errors
    if(error.status ==0)
    {
      console.error("Network error",error.error)
    }
    else
    {
      // error from server
      console.log("Error from the server",error.error);

    }
    // push to component
    return throwError(()=>{
      return new Error("Error, pls try again");

    })
  }
  checkCredentials(username:string,password:string)
  {
    var serverUrl="https://reqres.in/api/login";
    var userObj={
      email:username,
      password:password
    }
    userObj={
      "email": "eve.holt@reqres.in",
      "password": "cityslicka"
  };
    return this.httpService.post(serverUrl,userObj)
    .pipe(
      catchError(this.handleError)
    )
  }
  changeUsername(userId:number,name:string,job:string)
  {
    var serverUrl="https://reqres.in/api/users";
    var putUrl=serverUrl+"/"+userId
    var bodyData={
      name,job
    }
    return this.httpService.put(putUrl,bodyData)
    .pipe(
      catchError(this.handleError)
    );


  }
}
