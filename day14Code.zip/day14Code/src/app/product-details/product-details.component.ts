import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WorkWithProductsService } from '../work-with-products.service';
import { Products } from '../products';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent {
selectedProductId;
selectedProduct;
constructor(private currentRoute:ActivatedRoute, private workWithProduct:WorkWithProductsService)
{
  
  this.selectedProductId=this.currentRoute.snapshot.paramMap.get("pId");
  if(this.selectedProductId)
  {
    this.selectedProduct=this.workWithProduct.getProduct(parseInt(this.selectedProductId));
    
  }
  else
  {
    this.selectedProduct=null;
  }


}

}
