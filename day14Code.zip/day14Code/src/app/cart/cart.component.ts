import { Component,Input, OnDestroy, OnInit } from '@angular/core';
import { CartProduct } from '../cart-product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit,OnDestroy {
@Input() cartArr:CartProduct[];
today:Date;
colorsArr:Array<string>;
clearIntervalId:any;
h2Text:string;
salary:number;
countryName:string;
countryCode:string;
imgUrl:string;
imgUrlCorrect:string;
constructor(private router:Router)
{
  this.imgUrl="";
  this.imgUrlCorrect="./assets/DeloitteLogo.png"
  this.cartArr=new Array<CartProduct>();
  this.today=new Date();
  this.clearIntervalId=0;
  this.colorsArr=["red","pink","blue","violet","white"]
  this.h2Text='<p class="bg-primary">Hello Deloitte</p>';
  this.salary=1234.5678;
  this.countryName="India";
  this.countryCode="INR";
}
  ngOnDestroy(): void {
    clearInterval(this.clearIntervalId);
  }
  ngOnInit(): void {
  this.clearIntervalId=setInterval(()=>{
      this.today=new Date();
 
    },1000);
  }
  continueToPaymentEventHandler()
  {
    this.router.navigate(["/payment"]);
  }

}
