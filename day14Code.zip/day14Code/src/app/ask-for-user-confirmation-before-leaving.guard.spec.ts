import { TestBed } from '@angular/core/testing';
import { CanDeactivateFn } from '@angular/router';

import { askForUserConfirmationBeforeLeavingGuard } from './ask-for-user-confirmation-before-leaving.guard';

describe('askForUserConfirmationBeforeLeavingGuard', () => {
  const executeGuard: CanDeactivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => askForUserConfirmationBeforeLeavingGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
