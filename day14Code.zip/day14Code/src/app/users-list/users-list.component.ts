import { Component, OnInit } from '@angular/core';
import { TalkWithServerService } from '../talk-with-server.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {
  usersArr: any[];
  usersObservable: Observable<any>;
  constructor(private talkWithServer: TalkWithServerService) {
    this.usersArr = [];
    this.usersObservable = new Observable<any>();
  }
  ngOnInit(): void {
    this.usersObservable = this.talkWithServer.getAllUsersFromJsonPlaceholder();

    this.talkWithServer.getAllUsersFromReqRes()
      .subscribe((response: any) => {
        console.log(response.data);
        this.usersArr = response.data;
        //this.usersArr.push(response.data);


      })
  }
  changeNameEventHandler()
  {
    this.talkWithServer.changeUsername(2,"sara","IT")
    .subscribe((response)=>{
      console.log("Response as part of put request to change the name",response);
      if(response)
      {
        alert("Data updated successfully")
      }
    })
  }
}
