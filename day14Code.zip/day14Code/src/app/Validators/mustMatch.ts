import { FormGroup } from "@angular/forms";

export function mustMatch(controlName:string, matchingControlName:string)
{
    return function(formGroup:FormGroup)
    {
        let baseControl=formGroup.controls[controlName];
        let matchingControl=formGroup.controls[matchingControlName];
        // check if they exists
        if(!baseControl || !matchingControl)
        {
            return null;
        }
        // check for any existing errors
        if(baseControl.errors || matchingControl.errors)
        {
            return null;
        }
        // compare the values
        if(baseControl.value == matchingControl.value)
        {
            // return the error
            // validator is at the form level
            // set the error at the element(confirm password)
            matchingControl.setErrors(null);

        }
        else
        {
            matchingControl.setErrors({"passwordsMustMatch":true});
        }
        return null;
    }
}