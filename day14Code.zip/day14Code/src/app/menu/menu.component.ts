import { AfterContentChecked, AfterViewChecked, Component } from '@angular/core';
import { UserManagementService } from '../user-management.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements AfterContentChecked {
  loggedInStatus:boolean;
  username:string;
  constructor(private userManagement:UserManagementService)
  {
    this.loggedInStatus=userManagement.getLoggedInStatus();
    this.username=userManagement.getUsername();
  }
  ngAfterContentChecked(): void {
    this.loggedInStatus=this.userManagement.getLoggedInStatus();
    this.username=this.userManagement.getUsername();
  }

  logoutUserEventHandler()
  {
    this.userManagement.logoutUser();
  }
  

}

