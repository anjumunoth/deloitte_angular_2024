import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentExamplesComponent } from './content-examples.component';

describe('ContentExamplesComponent', () => {
  let component: ContentExamplesComponent;
  let fixture: ComponentFixture<ContentExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ContentExamplesComponent]
    });
    fixture = TestBed.createComponent(ContentExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
