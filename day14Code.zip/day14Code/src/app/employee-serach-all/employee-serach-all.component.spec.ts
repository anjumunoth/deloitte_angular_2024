import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeSerachAllComponent } from './employee-serach-all.component';

describe('EmployeeSerachAllComponent', () => {
  let component: EmployeeSerachAllComponent;
  let fixture: ComponentFixture<EmployeeSerachAllComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmployeeSerachAllComponent]
    });
    fixture = TestBed.createComponent(EmployeeSerachAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
