import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductListsComponent } from './product-lists/product-lists.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { checkProductIdGuard } from './check-product-id.guard';
import { ProductManagementComponent } from './product-management/product-management.component';
import { isUserAuthorisedGuard } from './is-user-authorised.guard';
import { askForUserConfirmationBeforeLeavingGuard } from './ask-for-user-confirmation-before-leaving.guard';
import { PaymentComponent } from './payment/payment.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByUpiComponent } from './payment-by-upi/payment-by-upi.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { RxjsExamplesComponent } from './rxjs-examples/rxjs-examples.component';
import { UsersListComponent } from './users-list/users-list.component';
// first match wins strategy
const routes: Routes = [
  {path:"products",component:HomeComponent},
  {path:"users",component:UsersListComponent},
  {path:"payment",component:PaymentComponent,
    children:[
      {path:"wallet",component:PaymentByWalletComponent},
      {path:"upi",component:PaymentByUpiComponent},
      {path:"card",component:PaymentByCardComponent},
      {path:"netbanking",component:PaymentByNetBankingComponent},
      {path:"",redirectTo:"/payment/upi", pathMatch:"full"}
    ]
},
  
  {path:"rxjs-examples",component:RxjsExamplesComponent},
  {path:"login",component:LoginComponent,canDeactivate:[askForUserConfirmationBeforeLeavingGuard]},
  {path:"register",component:RegisterComponent, canDeactivate:[askForUserConfirmationBeforeLeavingGuard]},
  {path:"product-details/:pId",component:ProductDetailsComponent,canActivate:[checkProductIdGuard]},
  {path:"edit-product",component:ProductManagementComponent,canActivate:[isUserAuthorisedGuard],canDeactivate:[askForUserConfirmationBeforeLeavingGuard]},
  {path:"", redirectTo:"products",pathMatch:"full"},
  {path:"**", component:PageNotFoundComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
