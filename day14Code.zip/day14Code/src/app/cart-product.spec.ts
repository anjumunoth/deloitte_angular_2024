import { CartProduct } from './cart-product';

describe('CartProduct', () => {
  it('should create an instance', () => {
    expect(new CartProduct()).toBeTruthy();
  });
});
