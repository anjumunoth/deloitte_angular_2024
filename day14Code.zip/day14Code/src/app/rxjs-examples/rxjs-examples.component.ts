import { Component } from '@angular/core';
import { Observable, from, of } from 'rxjs';
import { filter, take, map } from "rxjs/operators";


@Component({
  selector: 'app-rxjs-examples',
  templateUrl: './rxjs-examples.component.html',
  styleUrls: ['./rxjs-examples.component.css']
})
export class RxjsExamplesComponent {
  //numObservable$:Observable<any>;
  numArr:Array<number>;
  constructor()
  {
    // declare the observable
   let observableObj= new Observable((subscriber)=>{
      subscriber.next(1);
      subscriber.next(2);
      subscriber.next(3);
      subscriber.next(4);
      setTimeout(()=>{
        subscriber.next(5);
        subscriber.complete();
      },10000);
      return ()=>{
        // unsubscribe from the observable
        console.log("Time to wrap up from the observable");
      }
     
    })
    console.log("Before subscription");
    // subscribe to the observable; observable will get executed;
    let subscription1=observableObj.subscribe({
    next(num){
      console.log("Value in next",num);
    },
    complete()
    {
      console.log("Stream over");
    },
    error(err)
    {
      console.log("Error in observable",err)
    }
    })

    let subscription2=observableObj.subscribe({
      next(num){

        console.log("Value in next in second observer",(num));
      },
      complete()
      {
        console.log("Stream over in second observer");
      },
      error(err)
      {
        console.log("Error in observable",err)
      }
      })
      
    console.log("After subscription");
    //unsubscribe the observable
    subscription1.unsubscribe();

      // Operators:
      // from -- convert an array into an Observable
      this.numArr=[];
      var observableObj2=from([10,20,30,40]);
      var sub1=observableObj2.subscribe(
        (item )=>{console.log(item);
          console.log("Type of item in observable",typeof item);
        this.numArr.push(item);
      }
      )
       
      // of -- create an observable
      var observableObj3=of(1,2,3,4,5);
      var sub2=observableObj3.subscribe(
        (item )=>{console.log(item)}
      )

          //map, filter
      var observableObj4=of("red","blue","green","violet","black").pipe(
        map((item)=>{ return item.toUpperCase();})
      )

var sub3=observableObj4.subscribe(
        (item )=>{console.log(item)}
      )

      var observableObj5=of("red","blue","green","violet","black").pipe(
        filter((item)=> item.indexOf("e") >=0)
      )

var sub4=observableObj5.subscribe(
        (item )=>{console.log(item)}
      )
      console.log("Data with 2 opeartors applied");
      var observableObj6=of("red","blue","green","violet","black")
      .pipe( map((item)=>{ return item.toUpperCase();}))
      .pipe(
        filter((item)=> item.indexOf("E") >=0)
      )

var sub5=observableObj6.subscribe(
        (item )=>{console.log(item)}
      )



  }


}



