import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormControlDirective, FormGroup, Validators } from '@angular/forms';
import { UserManagementService } from '../user-management.service';
import { Router } from '@angular/router';
import { TalkWithServerService } from '../talk-with-server.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  constructor(private formBuilder: FormBuilder, private userService: UserManagementService, private router: Router, private talkWithServer: TalkWithServerService) {
    this.loginForm = this.formBuilder.group({
      username: new FormControl("", Validators.required),
      password: new FormControl("", Validators.required)
    })
  }
  loginEventHandler() {
    var username = this.loginForm.get('username')?.value;
    var password = this.loginForm.get('password')?.value;
    // check for credentials;
    try {
      this.talkWithServer.checkCredentials(username, password)
        .subscribe((response: any) => {
          console.log(response);
          if (!response.token) {
            alert("Username and password are incorrect");

          }
          else {
            // send the data to user management service
            this.userService.confirmLoggedIn(username);
            this.router.navigate(["/products"]);
          }
        })

    }
    catch(err)
    {
      console.log("Error",err);
      alert("Username and password are incorrect");
      

    }
  }
}
