import { CheckForStrongPasswordDirective } from './check-for-strong-password.directive';

describe('CheckForStrongPasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckForStrongPasswordDirective();
    expect(directive).toBeTruthy();
  });
});
