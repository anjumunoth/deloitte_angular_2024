import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import { ChildTemplateExampleComponent } from '../child-template-example/child-template-example.component';

@Component({
  selector: 'app-template-examples',
  templateUrl: './template-examples.component.html',
  styleUrls: ['./template-examples.component.css']
})
export class TemplateExamplesComponent implements AfterViewInit
{
@ViewChild("spanEmpName") spanEmpName:ElementRef|any;
@ViewChild("childTemplateRef") childTemplateRef:ChildTemplateExampleComponent|any;
 @ViewChild("childTemplateRef2",{read:ElementRef}) childTemplateRef2:ChildTemplateExampleComponent|any;
empArr:any[];
myColor:string;
myColor2:string;
constructor()
{
  this.myColor="blue";
  this.myColor2="pink"
  this.childTemplateRef=null;
  this.childTemplateRef=null;
  this.spanEmpName=null;
  this.empArr=[{
		"empId": 101,
		"empName": "asha",
		"salary": 1001,
		"deptId": "D1"
	}, {
		"empId": 102,
		"empName": "Gaurav",
		"salary": 2000,
		"deptId": "D1"
	}, {
		"empId": 103,
		"empName": "Karan",
		"salary": 2000,
		"deptId": "D2"
	},
	{
		"empId": 104,
		"empName": "Kishan",
		"salary": 3000,
		"deptId": "D1"
	},
	{
		"empId": 105,
		"empName": "Keshav",
		"salary": 3500,
		"deptId": "D2"
	},
	{
		"empId": 106,
		"empName": "Pran",
		"salary": 4000,
		"deptId":null,
		"hobbies":["singing","dancing","cooking"],
		"isMarried":false
	},
	{
		"empId": 107,
		"empName": "Saurav",
		"salary": 3800
	}
]
}
  ngAfterViewInit(): void {
    // hook will be called only once
    console.log("Child component class",this.childTemplateRef);
   console.log("Child component class",this.childTemplateRef2);
   this.childTemplateRef2.nativeElement.innerHTML="<p> Dynamic contents</p>"
  }
changeCase(name:string)
{
  alert("Button clicked"+ name.toUpperCase());
  console.log("Span element ",this.spanEmpName);
  this.spanEmpName.nativeElement.innerHTML=name.toUpperCase();
  

}
}
