import { Component } from '@angular/core';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee-search',
  templateUrl: './employee-search.component.html',
  styleUrls: ['./employee-search.component.css']
})
export class EmployeeSearchComponent {
empArr:Employee[];
fieldsInEmpArr:string[];
selectedFieldName:string;
selectedOrder:string;

constructor()
{

  this.empArr=new Array<Employee>();
  this.empArr .push(new Employee(101,"sara",1234555,new Date(2015,5,5)));
  this.empArr .push(new Employee(102,"tara",12341,new Date(2022,1,1)));
  this.empArr .push(new Employee(103,"lara",111234,new Date(2021,3,4)));
  this.empArr .push(new Employee(104,"gita",21234,new Date(2020,5,5)));
  this.empArr .push(new Employee(105,"sita",12324,new Date(1999,6,6)));
  this.empArr .push(new Employee(106,"ram",12342,new Date(2022,1,1)));
  this.empArr .push(new Employee(107,"shyam",12234,new Date(2024,0,22)));
  this.fieldsInEmpArr=Object.keys(this.empArr[0]);
  this.selectedFieldName=this.fieldsInEmpArr[3];
  this.selectedOrder="desc";
}
changeOrderEventHandler(ev:Event)
{
  console.log("Order change even",ev);
  console.log("ev.target",ev.target);
}
}
