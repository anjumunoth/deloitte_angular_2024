import { PasswordsMustMatchDirective } from './passwords-must-match.directive';

describe('PasswordsMustMatchDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordsMustMatchDirective();
    expect(directive).toBeTruthy();
  });
});
