import { Component, OnInit, Input } from '@angular/core';
import { WorkWithProductsService } from '../work-with-products.service';
import { Products } from '../products';

@Component({
  selector: 'app-edit-product-price',
  templateUrl: './edit-product-price.component.html',
  styleUrls: ['./edit-product-price.component.css']
})
export class EditProductPriceComponent implements OnInit {
  @Input() selectedProductId: number;
  selectedProduct: Products | any;
  constructor(private workWithProduct: WorkWithProductsService) {
    this.selectedProductId = 0;
    this.selectedProduct = null;
  }
  ngOnInit() {
    this.selectedProduct = this.workWithProduct.getProduct(this.selectedProductId);

  }
  changeEventHandler()
  {
    // input text box loses focus; finished typing and moved out of text box
    console.log("Change event triggered")
  }
  priceChangeEventHandler(event:any)
  {
    // similar to key press
    console.log("Input event triggered");
    this.selectedProduct.price=event.target.value;
  }
  saveEventHandler() {
    this.workWithProduct.updateProductPrice(this.selectedProduct);
  }
}
