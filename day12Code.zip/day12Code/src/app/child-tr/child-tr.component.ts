import { AfterContentInit, Component, ContentChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-child-tr',
  templateUrl: './child-tr.component.html',
  styleUrls: ['./child-tr.component.css']
})
export class ChildTrComponent implements AfterContentInit {
@ContentChild("content1") content1:ElementRef|any;
constructor()
{
  this.content1=null;
}
  ngAfterContentInit(): void {
    console.log("Contents in child tr component",this.content1);
  }
}
