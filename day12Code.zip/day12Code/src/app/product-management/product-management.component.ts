import { Component } from '@angular/core';
import { WorkWithProductsService } from '../work-with-products.service';
import { Products } from '../products';

@Component({
  selector: 'app-product-management',
  templateUrl: './product-management.component.html',
  styleUrls: ['./product-management.component.css']
})
export class ProductManagementComponent {
  productsArr:Array<Products>;
  selectedProductId:number;
  constructor( private workWithProducts:WorkWithProductsService)
  {
    //initialise the class variables
    // get a reference of the service  
    this.productsArr=workWithProducts.getProductsArr();// reference
    this.selectedProductId=0;
  }
  editPriceEventHandler(selectedProductId:number)
  {
    this.selectedProductId=selectedProductId;
  }
}
