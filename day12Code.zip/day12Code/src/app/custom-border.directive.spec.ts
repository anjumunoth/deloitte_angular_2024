import { CustomBorderDirective } from './custom-border.directive';

describe('CustomBorderDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomBorderDirective();
    expect(directive).toBeTruthy();
  });
});
