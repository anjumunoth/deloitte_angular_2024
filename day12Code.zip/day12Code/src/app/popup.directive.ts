import { Directive, OnInit,Input,HostListener, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appPopup]'
})
export class PopupDirective implements OnInit  {
  spanElement:any;
@Input() popUpText:string;
@HostListener("mouseenter") onMouseEnter()
{
     this.spanElement=this.renderer.createElement("span");
     var textElement=this.renderer.createText(this.popUpText);
     this.renderer.appendChild(this.spanElement,textElement);
     this.renderer.appendChild(this.el.nativeElement,this.spanElement);
     this.renderer.setStyle(this.spanElement,"z-index","1000");
     this.renderer.setStyle(this.spanElement,"background-color","brown");
     this.renderer.setStyle(this.spanElement,"color","yellow");
     this.renderer.setStyle(this.spanElement,"border","5px solid yellow");
     this.renderer.setStyle(this.spanElement,"position","absolute");
     let hostPos=this.el.nativeElement.getBoundingClientRect();
     console.log("Host pos",hostPos);
     let top= hostPos.bottom +10;
     let left=hostPos.left;
     this.renderer.setStyle(this.spanElement,"top",`${top}px`);
     this.renderer.setStyle(this.spanElement,"left",`${left}px`);


}
@HostListener("mouseout") onMouseOut()
{
  if(this.spanElement)
  {
  this.renderer.removeChild(this.el.nativeElement,this.spanElement);
  this.spanElement=null;
  }
  
}
  constructor(private el:ElementRef,private renderer:Renderer2) { 
    this.popUpText="Hello !!!";
    console.log("Directive's constructor called");
  }

  ngOnInit()
  {
    console.log("In popup  : popUpText",this.popUpText);
  }
}
