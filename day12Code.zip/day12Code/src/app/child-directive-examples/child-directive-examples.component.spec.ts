import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildDirectiveExamplesComponent } from './child-directive-examples.component';

describe('ChildDirectiveExamplesComponent', () => {
  let component: ChildDirectiveExamplesComponent;
  let fixture: ComponentFixture<ChildDirectiveExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ChildDirectiveExamplesComponent]
    });
    fixture = TestBed.createComponent(ChildDirectiveExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
