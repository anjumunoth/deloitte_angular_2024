import { Products } from "./products";

export class CartProduct extends Products{
    quantitySelected:number;
    constructor(pId:number,pName:string,price:number,quantity:number,desc: string, imgUrl:string,quantitySelected:number)
    {
       super(pId,pName,price,quantity,desc,imgUrl);
       this.quantitySelected=quantitySelected;
    }
}
