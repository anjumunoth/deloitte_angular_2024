import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const checkProductIdGuard: CanActivateFn = (route, state) => {
  let router=inject(Router);
  console.log("Route in canActivateGuard",route);
  console.log("State in canActivateGuard",state);
  let productId=route.params['pId'];
  if(productId && productId >0)
  {
    return true;
  }
  //console.log("Initial navigation",router.lastSuccessfulNavigation);
  router.navigate(["products"]);
  return false;
};
