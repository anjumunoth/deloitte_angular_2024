import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'defaultImage'
})
export class DefaultImagePipe implements PipeTransform {

  transform(value: string, ...args: string[]): string {
    if (value && value != "") {
      return value;
    }
    else
      if (args[0] && args[0] != "") {
        return args[0];
      }
      else {
        return "./assets/noImage.png"
      }

  }

}
