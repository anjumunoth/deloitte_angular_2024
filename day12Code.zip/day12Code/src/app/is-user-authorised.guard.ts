import { CanActivateFn, Router } from '@angular/router';
import { UserManagementService } from './user-management.service';
import { inject } from '@angular/core';

export const isUserAuthorisedGuard: CanActivateFn = (route, state) => {
  var userManagementService=inject(UserManagementService);
  var router=inject(Router);
  // authentication
  if(userManagementService.getLoggedInStatus())
  {
    if(userManagementService.getUsername().startsWith("admin"))
    {
      return true;
    }
  }
  router.navigate(["/login"]);
  return false;
};
