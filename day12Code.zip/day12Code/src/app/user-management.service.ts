import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {
  username:string;
  isUserLoggedIn:boolean;
  constructor() { 
    this.username="";
    this.isUserLoggedIn=false;
  }
  confirmLoggedIn(username:string)
  {
    this.username=username;
    this.isUserLoggedIn=true;
  }
  getLoggedInStatus()
  {
    return this.isUserLoggedIn;
  }
  getUsername()
  {
    return this.username;
  }
}
