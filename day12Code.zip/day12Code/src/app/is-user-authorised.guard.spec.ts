import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { isUserAuthorisedGuard } from './is-user-authorised.guard';

describe('isUserAuthorisedGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => isUserAuthorisedGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
