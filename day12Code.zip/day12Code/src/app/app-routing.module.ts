import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductListsComponent } from './product-lists/product-lists.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { checkProductIdGuard } from './check-product-id.guard';
import { ProductManagementComponent } from './product-management/product-management.component';
import { isUserAuthorisedGuard } from './is-user-authorised.guard';
// first match wins strategy
const routes: Routes = [
  {path:"products",component:HomeComponent},
  {path:"login",component:LoginComponent},
  {path:"register",component:RegisterComponent},
  {path:"product-details/:pId",component:ProductDetailsComponent,canActivate:[checkProductIdGuard]},
  {path:"edit-product",component:ProductManagementComponent,canActivate:[isUserAuthorisedGuard]},
  {path:"", redirectTo:"products",pathMatch:"full"},
  {path:"**", component:PageNotFoundComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
