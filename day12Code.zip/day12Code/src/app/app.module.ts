import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import {Footer} from "./footer/footer.component";
import { ProductListsComponent } from './product-lists/product-lists.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { InputExamplesComponent } from './input-examples/input-examples.component';
import { ParentInputExamplesComponent } from './parent-input-examples/parent-input-examples.component';
import { CartComponent } from './cart/cart.component';
import { HomeComponent } from './home/home.component';
import { TemplateExamplesComponent } from './template-examples/template-examples.component';
import { ChildTemplateExampleComponent } from './child-template-example/child-template-example.component';
import { ContentExamplesComponent } from './content-examples/content-examples.component';
import { ChildContentExamplesComponent } from './child-content-examples/child-content-examples.component';
import { ChildTrComponent } from './child-tr/child-tr.component';
import { DefaultImagePipe } from './default-image.pipe';
import { ProductSearchComponent } from './product-search/product-search.component';
import { EmployeeSearchComponent } from './employee-search/employee-search.component';
import { SortArrPipe } from './sort-arr.pipe';
import { EmployeeSerachAllComponent } from './employee-serach-all/employee-serach-all.component';
import { SearchArrPipe } from './search-arr.pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AttributeDirectiveExamplesComponent } from './attribute-directive-examples/attribute-directive-examples.component';
import { DirectiveExamplesComponent } from './directive-examples/directive-examples.component';
import { CustomBorderDirective } from './custom-border.directive';
import { ChildDirectiveExamplesComponent } from './child-directive-examples/child-directive-examples.component';
import { ImageHoverComponent } from './image-hover/image-hover.component';
import { ImageChangeDirective } from './image-change.directive';
import { CheckLengthDirective } from './check-length.directive';
import { PopupDirective } from './popup.directive';
import { PopUp2Directive } from './pop-up2.directive';
import { ProductManagementComponent } from './product-management/product-management.component';
import { EditProductPriceComponent } from './edit-product-price/edit-product-price.component';
import { WorkWithProductsService } from './work-with-products.service';
import { RegisterComponent } from './register/register.component';
import { UserManagementService } from './user-management.service';
import { CheckForStrongPasswordDirective } from './check-for-strong-password.directive';
import { PasswordsMustMatchDirective } from './passwords-must-match.directive';
import { AddProductComponent } from './add-product/add-product.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { HomeRootComponent } from './home-root/home-root.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProductDetailsComponent } from './product-details/product-details.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    Footer,
    ProductListsComponent,
    AddToCartComponent,
    InputExamplesComponent,
    ParentInputExamplesComponent,
    CartComponent,
    HomeComponent,
    TemplateExamplesComponent,
    ChildTemplateExampleComponent,
    ContentExamplesComponent,
    ChildContentExamplesComponent,
    ChildTrComponent,
    DefaultImagePipe,
    ProductSearchComponent,
    EmployeeSearchComponent,
    SortArrPipe,
    EmployeeSerachAllComponent,
    SearchArrPipe,
    AttributeDirectiveExamplesComponent,
    DirectiveExamplesComponent,
    CustomBorderDirective,
    ChildDirectiveExamplesComponent,
    ImageHoverComponent,
    ImageChangeDirective,
    CheckLengthDirective,
    PopupDirective,
    PopUp2Directive,
    ProductManagementComponent,
    EditProductPriceComponent,
    RegisterComponent,
    CheckForStrongPasswordDirective,
    PasswordsMustMatchDirective,
    AddProductComponent,
    LoginComponent,
    MenuComponent,
    HomeRootComponent,
    PageNotFoundComponent,
    ProductDetailsComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [WorkWithProductsService, UserManagementService],
  bootstrap: [AppComponent]
})
export class AppModule { }
