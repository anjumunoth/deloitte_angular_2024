import { Injectable } from '@angular/core';
import { Products } from './products';

@Injectable()
export class WorkWithProductsService {
  private productsArr:Array<Products>;
  constructor() { 
    this.productsArr=[
      new Products(101,"Apple 15 Pro Max",125000,12,"White Iphone Pro max 256gb","./assets/iphone15.jpeg"),
      new Products(102,"Oppo Fold",85000,5,"Oppo Fold 7.2 White Colour","./assets/oppofold.jpg"),
      new Products(103,"Pixel 8 Pro",55000,5,"Pixel 8 Pro","./assets/pixel8pro.jpg"),
      new Products(104,"Samsung Fold",150000,1,"Samsung Fold 7.2 White Colour","./assets/samsungfold4.jpg"),
      new Products(105,"Samsung Ultra 24Pr",115000,7,"Samsung Ultra24 White Colour","./assets/samsungs24.jpg"),
    ];
  }
  getProductsArr()
  {
    return this.productsArr;
  }
  getProduct(selectedProductId:number)
  {
    var selectedProduct=this.productsArr.find(item => item.productId == selectedProductId);
    if(selectedProduct)
    {
      return {...selectedProduct};// copy of object
    }
    else
      {
        return null;
      }
  }
  updateProductPrice(selectedProduct:Products)
  {
    //this.productsArr=[...this.productsArr,selectedProduct];
    var changedProductIndex=this.productsArr.findIndex(item => item.productId == selectedProduct.productId);
    this.productsArr[changedProductIndex].price=selectedProduct.price;


    

  }
}
