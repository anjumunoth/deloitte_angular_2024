import { Component, Input } from '@angular/core';
import {Products} from  "../products"

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent {
  quantitySelected:number;
@Input({required:true,alias:"selProduct"}) product:Products|null;

  constructor()
  {
    this.product=null;
    this.quantitySelected=1;
  }
  changeQuantitySelected(choice:string)
  {
    if(choice=="inc")
    {
      this.quantitySelected++;
    }
    else
    {
      this.quantitySelected--;
    }

  }
}
