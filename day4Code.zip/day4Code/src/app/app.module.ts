import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import {Footer} from "./footer/footer.component";
import { ProductListsComponent } from './product-lists/product-lists.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { InputExamplesComponent } from './input-examples/input-examples.component';
import { ParentInputExamplesComponent } from './parent-input-examples/parent-input-examples.component'

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    Footer,
    ProductListsComponent,
    AddToCartComponent,
    InputExamplesComponent,
    ParentInputExamplesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
