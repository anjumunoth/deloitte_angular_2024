import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-child-directive-examples',
  templateUrl: './child-directive-examples.component.html',
  styleUrls: ['./child-directive-examples.component.css']
})
export class ChildDirectiveExamplesComponent  implements OnInit{
  @Input() popUpText:string;
  constructor() { 
    this.popUpText=""
    console.log("Child directive example constructor called");

  }
  ngOnInit()
  {
    console.log("In Child Componenet on Init : popUpText",this.popUpText);
  }

}
