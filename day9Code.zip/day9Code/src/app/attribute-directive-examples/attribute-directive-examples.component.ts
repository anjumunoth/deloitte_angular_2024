import { Component } from '@angular/core';

@Component({
  selector: 'app-attribute-directive-examples',
  templateUrl: './attribute-directive-examples.component.html',
  styleUrls: ['./attribute-directive-examples.component.css']
})
export class AttributeDirectiveExamplesComponent {
  quantity:number;
  //selectedClasses:string[];
  selectedClasses:object;

  constructor()
  {
    //this.selectedClasses="bg-primary text-light";
    //this.selectedClasses=["bg-primary", "text-light"]
    this.selectedClasses={"bg-primary":true,"text-light":true}
    this.quantity=0;
    
  }
  applyTheme(selectedTheme:string)
  {
    if(selectedTheme =="dark")
    {  
      //this.selectedClasses="bg-primary text-light";
      //this.selectedClasses=["bg-primary", "text-light"]
      this.selectedClasses={"bg-primary":true,"text-light":true}
  }
  else
  {
    //this.selectedClasses="bg-light text-dark";
    //this.selectedClasses=["bg-light", "text-dark"]
    this.selectedClasses={"bg-primary":false,"bg-light":true,"text-dark":this.quantity==0}
  }
  }
}
