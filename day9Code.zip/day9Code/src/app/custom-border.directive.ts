import { Directive,ElementRef,HostListener,Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appCustomBorder]'
})
export class CustomBorderDirective implements OnInit{
   @Input() appCustomBorder:string;
   @Input() bgStyle:string;
   @Input() fontColor:string;
   @Input() textSize:string;
@HostListener("click") onClick()
{
  this.el.nativeElement.style.border="5px dotted blue";
}
@HostListener("mouseenter") onMouseEnter()
{
  this.el.nativeElement.style.border="5px dashed yellow";
}
@HostListener("mouseleave") onMouseLeave()
{
  this.el.nativeElement.style.border="5px double pink";
}
  constructor(private el:ElementRef) { 
    this.el.nativeElement.style.border="5px double pink";
    this.appCustomBorder="5px double pink";
    this.bgStyle="white";
    console.log(this.el.nativeElement);
    this.fontColor="black";
    this.textSize="20px";
  }
  ngOnInit(): void {
    this.el.nativeElement.style.border=this.appCustomBorder;
    if(this.bgStyle)
    {
      this.el.nativeElement.style.background=this.bgStyle;
    }
    if(this.fontColor)
    {
      this.el.nativeElement.style.color=this.fontColor
    }
    if(this.textSize)
    {
      this.el.nativeElement.style.fontSize=this.textSize;
    }
  }


}
