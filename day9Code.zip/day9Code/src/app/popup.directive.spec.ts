import { PopupDirective } from './popup.directive';

describe('PopupDirective', () => {
  it('should create an instance', () => {
    const directive = new PopupDirective();
    expect(directive).toBeTruthy();
  });
});
