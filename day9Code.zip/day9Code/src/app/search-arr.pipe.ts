import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchArr'
})
export class SearchArrPipe implements PipeTransform {

  transform(value:any,searchTerm :string,searchField:any)
   {

    if(!searchTerm ||searchTerm=="")
    {
      return value;
    }
    if(!searchField || searchField=="")
    {
      return value;
    }
    var fieldsInArr=Object.keys(value[0]);
    var pos=fieldsInArr.findIndex(item => item == searchField)
    if(pos <0)
    {
      return value;
    }
    // lets start the filterin
    // depends on data type of searchField
    var filteredRecords=value;
    console.log("Type of search filed",typeof(value[0][searchField]));
    console.log(searchTerm.toString().toLowerCase());
    console.log(value[0][searchField].toString().toLowerCase());
    
    if(value[0][searchField] instanceof(Date))
    {
      filteredRecords=value.filter((item:any) => 
      {
        console.log("Search term",(new Date(searchTerm)).toDateString() );
        console.log("Item value",item[searchField].toDateString())
        if(item[searchField].toDateString() == (new Date(searchTerm)).toDateString() )
          return item;
        
      })
      console.log(filteredRecords);
      return filteredRecords;
    }

     if( typeof(value[0][searchField] == "string"))
    {
    
       filteredRecords=value.filter(
        (item:any) =>item[searchField].toString().toLowerCase().startsWith(searchTerm.toString().toLowerCase()));
       
    } 
    
console.log(searchTerm.toString().toLowerCase());
//filteredRecords=value.filter((a:any)=>a[searchFiled].toString().toUpperCase().startsWith(searchRecord.toString().toUpperCase())); 



    if( typeof(value[0][searchField] == "number"))
    {
      filteredRecords=value.filter((item:any) => item[searchField].toString().startsWith(searchTerm.toString()));
    }
   /*  if( typeof(value[0][searchField] == "object"))
    {

    }
 */

    
    return filteredRecords;
  }

}
