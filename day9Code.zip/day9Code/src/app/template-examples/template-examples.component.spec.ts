import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateExamplesComponent } from './template-examples.component';

describe('TemplateExamplesComponent', () => {
  let component: TemplateExamplesComponent;
  let fixture: ComponentFixture<TemplateExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TemplateExamplesComponent]
    });
    fixture = TestBed.createComponent(TemplateExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
