import { Component } from "@angular/core";

@Component({
    selector:"app-footer",
    template:`
    <div>
        <h1>Footer</h1>
</div>
    `,
    styles:[
        "h1 {font-weight:bold;color:white;background-color:black;}"
]
})
export class Footer{

}